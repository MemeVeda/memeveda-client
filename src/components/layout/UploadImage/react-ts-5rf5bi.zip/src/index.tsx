import React from 'react';
import { render } from 'react-dom';

import { Button, notification } from 'antd';

const openNotification = () => {
  const args = {
    message: 'Notification Title',
    description:
      'I will never close automatically. This is a purposely very very long description that has many many characters and words.',
    duration: 0,
  };
  notification.open(args);
};

const App = () => {
  return (
    <div>
      <Button type="primary" onClick={() => openNotification()}>
        {' '}
        Notification{' '}
      </Button>
    </div>
  );
};

render(<App />, document.getElementById('root'));
